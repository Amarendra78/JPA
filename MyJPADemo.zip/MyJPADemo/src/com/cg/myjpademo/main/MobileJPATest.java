package com.cg.myjpademo.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.myjpademo.entity.Mobile;

public class MobileJPATest {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("MyPersistanceUnit");
		
		EntityManager em=emf.createEntityManager();
		
		Mobile m1=new Mobile();
		m1.setMobile_company("Samsung");
		em.getTransaction().begin();
		System.out.println("active transaction...");
		em.persist(m1);
		System.out.println("Mobile object added...");
		em.getTransaction().commit();
		
		em.close();
		emf.close();
		
		

	}

}
