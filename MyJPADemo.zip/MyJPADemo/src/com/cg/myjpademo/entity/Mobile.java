package com.cg.myjpademo.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Mobile_Details")
public class Mobile implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int mobile_id;
	
	@Column(name="MfgCompany")
	private String mobile_company;
	
	
	public int getMobile_id() {
		return mobile_id;
	}
	public void setMobile_id(int mobile_id) {
		this.mobile_id = mobile_id;
	}
	public String getMobile_company() {
		return mobile_company;
	}
	public void setMobile_company(String mobile_company) {
		this.mobile_company = mobile_company;
	}
	
	
	
	
}
